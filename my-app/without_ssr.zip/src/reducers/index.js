import {combineReducers} from "redux";
import formReducers from "./formReducers";

export default combineReducers({formReducers});